<section>
    <div class="container">
        <div class="section-heading">
            <span class="alt-font">Working Process</span>
            <h2>Bold approaches expert counsel results that matter</h2>
        </div>
        <div class="row process-number-counter mt-n1-9">
            <div class="col-sm-6 col-lg-3 mt-1-9">
                <div class="process-style1">
                    <div class="process-img">
                        <img src="{{asset("v1/process/img4.png")}}" class="rounded-circle" alt="...">
                    </div>
                    <div class="process-number"></div>
                    <h3 class="mb-3 h4">Listen Problems</h3>
                    <p class="w-md-85 mx-auto mb-4">The protection calling is one that accompanies great monetary prize.</p>
                    <div class="process-btn"><a href="jvoid:avascrip()"><i class="fas fa-arrow-right"></i></a></div>
                </div>
            </div>
            <div class="col-sm-6 col-lg-3 mt-1-9">
                <div class="process-style1">
                    <div class="process-img">
                        <img src="{{asset("v1/process/img2.png")}}" class="rounded-circle" alt="...">
                    </div>
                    <div class="process-number"></div>
                    <h3 class="mb-3 h4">Some Research</h3>
                    <p class="w-md-85 mx-auto mb-4">The protection calling is one that accompanies great monetary prize.</p>
                    <div class="process-btn"><a href="jvoid:avascrip()"><i class="fas fa-arrow-right"></i></a></div>
                </div>
            </div>
            <div class="col-sm-6 col-lg-3 mt-1-9">
                <div class="process-style1">
                    <div class="process-img">
                        <img src="{{asset("v1/process/img3.png")}}" class="rounded-circle" alt="...">
                    </div>
                    <div class="process-number"></div>
                    <h3 class="mb-3 h4">Make Shorting</h3>
                    <p class="w-md-85 mx-auto mb-4">The protection calling is one that accompanies great monetary prize.</p>
                    <div class="process-btn"><a href="jvoid:avascrip()"><i class="fas fa-arrow-right"></i></a></div>
                </div>
            </div>
            <div class="col-sm-6 col-lg-3 mt-1-9">
                <div class="process-style1 last-arrow">
                    <div class="process-img">
                        <img src="{{asset("v1/process/img1.png")}}" class="rounded-circle" alt="...">
                    </div>
                    <div class="process-number"></div>
                    <h3 class="mb-3 h4">Do Final Work</h3>
                    <p class="w-md-85 mx-auto mb-4">The protection calling is one that accompanies great monetary prize.</p>
                    <div class="process-btn"><a href="jvoid:avascrip()"><i class="fas fa-arrow-right"></i></a></div>
                </div>
            </div>
        </div>
    </div>
</section>
