<link href="{{ asset('/') }}vendors/simplebar/simplebar.min.css" rel="stylesheet">
{{-- <link href="{{ asset('/') }}assets/css/theme-rtl.min.css" rel="stylesheet" id="style-rtl"> --}}
<link href="{{ asset('/') }}assets/css/theme.min.css" rel="stylesheet" id="style-default">
{{-- <link href="{{ asset('/') }}assets/css/user-rtl.min.css" rel="stylesheet" id="user-style-rtl"> --}}
{{-- <link href="{{ asset('/') }}assets/css/user.min.css" rel="stylesheet" id="user-style-default"> --}}
{{-- <script src="{{ asset('/') }}vendors/choices/choices.min.css"></script> --}}

