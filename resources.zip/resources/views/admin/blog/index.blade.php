@extends('admin.layouts.app')
@section('content')
    <h1>Blog Posts</h1>
    <a href="{{ route('blogs.create') }}">Create New Blog</a>
    @foreach ($blogs as $blog)
        <div>
            <h2><a href="{{ route('blog.show', $blog->slug) }}">{{ $blog->title }}</a></h2>
            <p>{{ $blog->excerpt }}</p>
        </div>
    @endforeach
    {{ $blogs->links() }}
@endsection
