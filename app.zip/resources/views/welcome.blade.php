<!DOCTYPE html>
<html lang="en">


<!-- Mirrored from lawyer.websitelayout.net/ by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 25 Feb 2025 19:49:55 GMT -->
<head>

    <!-- metas -->
    <meta charset="utf-8">
    <meta name="author" content="Chitrakoot Web" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="keywords" content="Attorney and Lawyers HTML Template" />
    <meta name="description" content="Lawyer - Attorney and Lawyers HTML Template" />

    <!-- title  -->
    <title>Lawyer - Attorney Pema PLB</title>

    <!-- favicon -->
    <link rel="shortcut icon" href="{{asset("v1")}}/img/logos/favicon.png" />
    <link rel="apple-touch-icon" href="{{asset("v1")}}/img/logos/apple-touch-icon-57x57.png" />
    <link rel="apple-touch-icon" sizes="72x72" href="{{asset("v1")}}/img/logos/apple-touch-icon-72x72.png" />
    <link rel="apple-touch-icon" sizes="114x114" href="{{asset("v1")}}/img/logos/apple-touch-icon-114x114.png" />

    <!-- plugins -->
    <link rel="stylesheet" href="{{asset("v1")}}/css/plugins.css" />

    <!-- search css -->
    <link rel="stylesheet" href="{{asset("v1")}}/search/search.css" />

    <!-- quform css -->
    <link rel="stylesheet" href="{{asset("v1")}}/quform/css/base.css">

    <!-- theme core css -->
    <link href="{{asset("v1")}}/css/styles.css" rel="stylesheet">

</head>

<body>

    <!-- PAGE LOADING
    ================================================== -->
    <div id="preloader"></div>

    <!-- MAIN WRAPPER
    ================================================== -->
    <div class="main-wrapper">

        <!-- HEADER
        ================================================== -->
        <header class="header-style1 menu_area-light">

            <div class="navbar-default border-bottom border-color-light-white">

                <!-- start top search -->
                <div class="top-search bg-primary">
                    <div class="container-fluid px-lg-1-6 px-xl-2-5 px-xxl-2-9">
                        <form class="search-form" action="https://lawyer.websitelayout.net/search.html" method="GET" accept-charset="utf-8">
                            <div class="input-group">
                                <span class="input-group-addon cursor-pointer">
                                    <button class="search-form_submit fas fa-search text-white" type="submit"></button>
                                </span>
                                <input type="text" class="search-form_input form-control" name="s" autocomplete="off" placeholder="Type & hit enter...">
                                <span class="input-group-addon close-search mt-1"><i class="fas fa-times"></i></span>
                            </div>
                        </form>
                    </div>
                </div>
                <!-- end top search -->

                <div class="container-fluid px-lg-1-6 px-xl-2-5 px-xxl-2-9">
                    <div class="row align-items-center">
                        <div class="col-12 col-lg-12">
                            <div class="menu_area alt-font">
                                <nav class="navbar navbar-expand-lg navbar-light p-0">
                                    <div class="navbar-header navbar-header-custom">
                                        <!-- start logo -->
                                        <a href="{{ url('/') }}" class="navbar-brand"><img  src="{{ asset('website/logo.png') }}" alt="logo"></a>
                                        <!-- end logo -->
                                    </div>

                                    <div class="navbar-toggler"></div>

                                    <!-- start menu area -->
                                    <ul class="navbar-nav ms-auto" id="nav" style="display: none;">
                                        <li><a href="{{asset("v1")}}/#!">Home</a>
                                            <ul>
                                                <li><a href="{{asset("v1")}}/index-2.html">Home 01</a></li>
                                                <li><a href="{{asset("v1")}}/index-3.html">Home 02</a></li>
                                                <li><a href="{{asset("v1")}}/index-4.html">Home 03</a></li>
                                            </ul>
                                        </li>
                                        <li><a href="{{asset("v1")}}/#!">Pages</a>
                                            <ul>
                                                <li><a href="{{asset("v1")}}/about.html">About Us</a></li>
                                                <li><a href="{{asset("v1")}}/our-history.html">Our History</a></li>
                                                <li><a href="{{asset("v1")}}/achievements.html">Achievements</a></li>
                                                <li>
                                                    <a href="{{asset("v1")}}/#!">Our Attorneys</a>
                                                    <ul>
                                                        <li><a href="{{asset("v1")}}/our-attorneys.html">Our Attorneys</a></li>
                                                        <li><a href="{{asset("v1")}}/attorney-details.html">Attorney Details</a></li>
                                                    </ul>
                                                </li>
                                                <li><a href="{{asset("v1")}}/#!">Additional Pages</a>
                                                    <ul>
                                                        <li><a href="{{asset("v1")}}/testimonial.html">Testimonial</a></li>
                                                        <li><a href="{{asset("v1")}}/our-pricing.html">Our Pricing</a></li>
                                                        <li><a href="{{asset("v1")}}/faq.html">FAQ</a></li>
                                                    </ul>
                                                </li>
                                                <li><a href="{{asset("v1")}}/#!">Others</a>
                                                    <ul>
                                                        <li><a href="{{asset("v1")}}/coming-soon.html">Comingsoon</a></li>
                                                        <li><a href="{{asset("v1")}}/404-page.html">404 Page</a></li>
                                                    </ul>
                                                </li>
                                                <li><a href="{{asset("v1")}}/contact.html">Contact Us</a></li>
                                            </ul>
                                        </li>
                                        <li><a href="{{asset("v1")}}/#!">Services</a>
                                            <ul>
                                                <li><a href="{{asset("v1")}}/services.html">Our Services</a></li>
                                                <li><a href="{{asset("v1")}}/business-law.html">Business Law</a></li>
                                                <li><a href="{{asset("v1")}}/criminal-law.html">Criminal Law</a></li>
                                                <li><a href="{{asset("v1")}}/divorce-law.html">Divorce Law</a></li>
                                                <li><a href="{{asset("v1")}}/education-law.html">Education Law</a></li>
                                                <li><a href="{{asset("v1")}}/family-law.html">Family Law</a></li>
                                                <li><a href="{{asset("v1")}}/insurance-law.html">Insurance Law</a></li>
                                            </ul>
                                        </li>
                                        <li><a href="{{asset("v1")}}/#!">Case Study</a>
                                            <ul>
                                                <li><a href="{{asset("v1")}}/case-study-3-col.html">Case Study 3 Col</a></li>
                                                <li><a href="{{asset("v1")}}/case-study-4-col.html">Case Study 4 Col</a></li>
                                                <li><a href="{{asset("v1")}}/case-study-details.html">Case Study Details</a></li>
                                            </ul>
                                        </li>
                                        <li><a href="{{asset("v1")}}/#!">Blog</a>
                                            <ul>
                                                <li><a href="{{asset("v1")}}/blog-grid.html">Blog Grid</a></li>
                                                <li><a href="{{asset("v1")}}/blog-list.html">Blog List</a></li>
                                                <li><a href="{{asset("v1")}}/blog-details.html">Blog Details</a></li>
                                            </ul>
                                        </li>
                                        <li><a href="{{asset("v1")}}/#!">Elements</a>
                                            <ul class="row megamenu">
                                                <li class="col-lg-3 col-sm-12">
                                                    <span class="mb-0 mb-lg-3 d-block py-2 p-lg-0 px-4 px-lg-0 text-uppercase sub-title font-weight-800">Elements 01</span>
                                                    <ul>
                                                        <li><a href="{{asset("v1")}}/accordion.html"><i class="fas fa-sliders-h me-2"></i>Accordion</a></li>
                                                        <li><a href="{{asset("v1")}}/alerts.html"><i class="far fa-bell me-2"></i>Alerts</a></li>
                                                        <li><a href="{{asset("v1")}}/blockquotes.html"><i class="fas fa-vector-square me-2"></i>Blockquotes</a></li>
                                                        <li><a href="{{asset("v1")}}/buttons.html"><i class="fas fa-link me-2"></i>Buttons</a></li>
                                                        <li><a href="{{asset("v1")}}/call-to-action.html"><i class="far fa-square me-2"></i>Call to Action</a></li>
                                                        <li><a href="{{asset("v1")}}/carousel-slider.html"><i class="far fa-images me-2"></i>Carousel Slider</a></li>
                                                    </ul>
                                                </li>
                                                <li class="col-lg-3 col-sm-12">
                                                    <span class="mb-0 mb-lg-3 d-block py-2 p-lg-0 px-4 px-lg-0 text-uppercase sub-title font-weight-800">Elements 02</span>
                                                    <ul>
                                                        <li><a href="{{asset("v1")}}/count-down.html"><i class="far fa-flag me-2"></i>Count Down</a></li>
                                                        <li><a href="{{asset("v1")}}/counters.html"><i class="fas fa-compress me-2"></i>Counters</a></li>
                                                        <li><a href="{{asset("v1")}}/dropcaps.html"><i class="far fa-closed-captioning me-2"></i>Dropcaps</a></li>
                                                        <li><a href="{{asset("v1")}}/forms.html"><i class="fab fa-wpforms me-2"></i>Forms</a></li>
                                                        <li><a href="{{asset("v1")}}/font-icons.html"><i class="far fa-check-square me-2"></i>Font Icons</a></li>
                                                        <li><a href="{{asset("v1")}}/google-map.html"><i class="fas fa-map-marker-alt me-2"></i>Google Map</a></li>
                                                    </ul>
                                                </li>
                                                <li class="col-lg-3 col-sm-12">
                                                    <span class="mb-0 mb-lg-3 d-block py-2 p-lg-0 px-4 px-lg-0 text-uppercase sub-title font-weight-800">Elements 03</span>
                                                    <ul>
                                                        <li><a href="{{asset("v1")}}/grid-system.html"><i class="fas fa-th me-2"></i>Grid System</a></li>
                                                        <li><a href="{{asset("v1")}}/highlights.html"><i class="fas fa-highlighter me-2"></i>Highlights</a></li>
                                                        <li><a href="{{asset("v1")}}/icon-with-text.html"><i class="fab fa-fonticons-fi me-2"></i>Icon With Text</a></li>
                                                        <li><a href="{{asset("v1")}}/list-styles.html"><i class="fas fa-list-ul me-2"></i>List Styles</a></li>
                                                        <li><a href="{{asset("v1")}}/media-object.html"><i class="fas fa-photo-video me-2"></i>Media Object</a></li>
                                                        <li><a href="{{asset("v1")}}/modal.html"><i class="fas fa-expand me-2"></i>Modal</a></li>
                                                    </ul>
                                                </li>
                                                <li class="col-lg-3 col-sm-12">
                                                    <span class="mb-0 mb-lg-3 d-block py-2 p-lg-0 px-4 px-lg-0 text-uppercase sub-title font-weight-800">Elements 04</span>
                                                    <ul>
                                                        <li><a href="{{asset("v1")}}/pagination.html"><i class="far fa-caret-square-right me-2"></i>Pagination</a></li>
                                                        <li><a href="{{asset("v1")}}/progress-bars.html"><i class="fas fa-tasks me-2"></i>Progress Bars</a></li>
                                                        <li><a href="{{asset("v1")}}/tables.html"><i class="fas fa-table me-2"></i>Tables</a></li>
                                                        <li><a href="{{asset("v1")}}/tabs.html"><i class="fas fa-sliders-h me-2"></i>Tabs</a></li>
                                                        <li><a href="{{asset("v1")}}/typography.html"><i class="fas fa-text-height me-2"></i>Typography</a></li>
                                                        <li><a href="{{asset("v1")}}/videos.html"><i class="fas fa-video me-2"></i>Videos</a></li>
                                                    </ul>
                                                </li>
                                            </ul>
                                        </li>
                                    </ul>
                                    <!-- end menu area -->

                                    <!-- start attribute navigation -->
                                    <div class="attr-nav align-items-xl-center ms-xl-auto main-font">
                                        <ul>
                                            <li class="search"><a href="{{asset("v1")}}/#!"><i class="fas fa-search"></i></a></li>
                                            <li class="d-none d-xl-inline-block"><a href="{{asset("v1")}}/contact.html" class="butn md text-white">Free Consultation</a></li>
                                        </ul>
                                    </div>
                                    <!-- end attribute navigation -->
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>

        <!-- BANNER
        ================================================== -->
        <div class="slider-fade banner1 top-position1">
            <div class="owl-carousel owl-theme w-100">
                <div class="text-start item bg-img secondary-overlay" data-overlay-dark="8" data-background="{{asset("v1")}}/img/bg-1.jpg">
                    <div class="container h-100">
                        <div class="d-table h-100 w-100">
                            <div class="d-table-cell align-middle caption">
                                <div class="overflow-hidden w-95 w-md-85 w-lg-75">
                                    <span class="sub-title">Professional lawyers</span>
                                    <h1>Liberty and justice for everybody</h1>
                                    <p class="w-lg-80">We give best law administration to customers and attempt to accomplish our customers trust.</p>
                                    <a href="{{asset("v1")}}/about.html" class="butn butn-white butn-hover">Learn More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="text-center item bg-img secondary-overlay" data-overlay-dark="8" data-background="{{asset("v1")}}/img/bg-2.jpg">

                    <div class="container h-100">
                        <div class="d-table h-100 w-100">
                            <div class="d-table-cell align-middle caption">
                                <div class="w-md-75 mx-auto">
                                    <span class="sub-title">Introduce lawsight</span>
                                    <h1>We are here to secure any sort of violence</h1>
                                    <p class="w-lg-80 mx-auto">We give best law administration to customers and attempt to accomplish our customers trust.</p>
                                    <a href="{{asset("v1")}}/about.html" class="butn butn-white butn-hover">Learn More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="text-end item bg-img secondary-overlay" data-overlay-dark="8" data-background="{{asset("v1")}}/img/bg-3.jpg">
                    <div class="container h-100">
                        <div class="d-table h-100 w-100">
                            <div class="d-table-cell align-middle caption">
                                <div class="overflow-hidden w-95 w-md-85 w-lg-75">
                                    <span class="sub-title">Strong team of leaders</span>
                                    <h1>Finest & strongest law firm in the world</h1>
                                    <p class="w-lg-80 ms-auto">We give best law administration to customers and attempt to accomplish our customers trust.</p>
                                    <a href="{{asset("v1")}}/about.html" class="butn butn-white butn-hover">Learn More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- ABOUTUS
        ================================================== -->
        <section class="about-style1">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-6 mb-2-5 mb-lg-0">
                        <div class="position-relative">
                            <div class="position-relative z-index-1 py-2-9 py-xl-7 px-1-6 px-md-2-9 px-lg-2-5 px-xl-2-9">
                                <img src="{{asset("v1")}}/img/about1.jpg" alt="...">
                            </div>
                            <span class="position-absolute top-0 start-0 z-index-0"><img src="{{asset("v1")}}/img/content/bg-pattern.png" alt="..."></span>
                            <div class="about-counter">
                                <h4 class="countup">20</h4>
                                <span class="fs-5 font-weight-500">Years Of Experience</span>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="ps-lg-2-5 ps-xl-6">
                            <h2 class="h1 mb-1-6">We are the most popular law firm</h2>
                            <p class="lead mb-1-6">We offer our clients fresh perspectives and breakthrough business insights.</p>
                            <div class="border-start border-primary border-width-3 ps-4">
                                <p class="fst-italic">Lawyer is worth much more than I paid. Lawyer did exactly what you said it does. I could probably go into sales for you.</p>
                                <h6 class="small text-capitalize m-0">- Marion Shepard</h6>
                            </div>
                            <div class="dotted-seprator"></div>
                            <div class="row mb-1-9 mb-xl-2-5">
                                <div class="col-sm-6">
                                    <ul class="list-style1 mb-2 mb-sm-0">
                                        <li>Expert legal serives.</li>
                                        <li>100% success rate.</li>
                                        <li>No consultation.</li>
                                    </ul>
                                </div>
                                <div class="col-sm-6">
                                    <ul class="list-style1">
                                        <li>Professional approach.</li>
                                        <li>Expert attorneys.</li>
                                        <li>Probably law firm.</li>
                                    </ul>
                                </div>
                            </div>
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0">
                                    <img src="{{asset("sign.png")}}" alt="..." width="100px">
                                </div>
                                <div class="flex-grow-1 border-start border-width-2 border-color-extra-light-gray ps-3 ps-sm-4 ms-3 ms-sm-4">
                                    <h5>Gloria Fleming</h5>
                                    <p class="mb-0">Founder</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- SERVICE
        ================================================== -->
        <section class="bg-light">
            <div class="container">
                <div class="section-heading">
                    <span class="alt-font">Practice Areas</span>
                    <h2>Innovation and client focused our practice area</h2>
                </div>
                <div class="row mt-n1-9">
                    <div class="col-md-6 col-lg-4 mt-1-9">
                        <div class="card card-style1">
                            <div class="card-body">
                                <div class="icon">
                                    <img src="{{asset("v1")}}/img/icons/icon-01.png" alt="...">
                                </div>
                                <h3 class="mb-3 h4"><a href="{{asset("v1")}}/business-law.html">Business Law</a></h3>
                                <p class="mb-3 w-95 mx-auto">Our accomplished lawyer offer incredible preliminary planning.</p>
                                <a href="{{asset("v1")}}/business-law.html" class="font-weight-500">Read more<i class="fas fa-long-arrow-alt-right align-middle ms-2 display-30"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-4 mt-1-9">
                        <div class="card card-style1">
                            <div class="card-body">
                                <div class="icon">
                                    <img src="{{asset("v1")}}/img/icons/icon-02.png" alt="...">
                                </div>
                                <h3 class="mb-3 h4"><a href="{{asset("v1")}}/criminal-law.html">Criminal Law</a></h3>
                                <p class="mb-3 w-95 mx-auto">Our accomplished lawyer offer incredible preliminary planning.</p>
                                <a href="{{asset("v1")}}/criminal-law.html" class="font-weight-500">Read more<i class="fas fa-long-arrow-alt-right align-middle ms-2 display-30"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-4 mt-1-9">
                        <div class="card card-style1">
                            <div class="card-body">
                                <div class="icon">
                                    <img src="{{asset("v1")}}/img/icons/icon-03.png" alt="...">
                                </div>
                                <h3 class="mb-3 h4"><a href="{{asset("v1")}}/divorce-law.html">Divorce Law</a></h3>
                                <p class="mb-3 w-95 mx-auto">Our accomplished lawyer offer incredible preliminary planning.</p>
                                <a href="{{asset("v1")}}/divorce-law.html" class="font-weight-500">Read more<i class="fas fa-long-arrow-alt-right align-middle ms-2 display-30"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-4 mt-1-9">
                        <div class="card card-style1">
                            <div class="card-body">
                                <div class="icon">
                                    <img src="{{asset("v1")}}/img/icons/icon-04.png" alt="...">
                                </div>
                                <h3 class="mb-3 h4"><a href="{{asset("v1")}}/education-law.html">Education Law</a></h3>
                                <p class="mb-3 w-95 mx-auto">Our accomplished lawyer offer incredible preliminary planning.</p>
                                <a href="{{asset("v1")}}/education-law.html" class="font-weight-500">Read more<i class="fas fa-long-arrow-alt-right align-middle ms-2 display-30"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-4 mt-1-9">
                        <div class="card card-style1">
                            <div class="card-body">
                                <div class="icon">
                                    <img src="{{asset("v1")}}/img/icons/icon-05.png" alt="...">
                                </div>
                                <h3 class="mb-3 h4"><a href="{{asset("v1")}}/family-law.html">Family Law</a></h3>
                                <p class="mb-3 w-95 mx-auto">Our accomplished lawyer offer incredible preliminary planning.</p>
                                <a href="{{asset("v1")}}/family-law.html" class="font-weight-500">Read more<i class="fas fa-long-arrow-alt-right align-middle ms-2 display-30"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 mt-1-9">
                        <div class="card card-style1">
                            <div class="card-body">
                                <div class="icon">
                                    <img src="{{asset("v1")}}/img/icons/icon-06.png" alt="...">
                                </div>
                                <h3 class="mb-3 h4"><a href="{{asset("v1")}}/insurance-law.html">Insurance Law</a></h3>
                                <p class="mb-3 w-95 mx-auto">Our accomplished lawyer offer incredible preliminary planning.</p>
                                <a href="{{asset("v1")}}/insurance-law.html" class="font-weight-500">Read more<i class="fas fa-long-arrow-alt-right align-middle ms-2 display-30"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- COUNTER
        ================================================== -->
        <section class="bg-img cover-background secondary-overlay" data-overlay-dark="8" data-background="{{asset("v1")}}/img/bg/bg-07.jpg">
            <div class="container">
                <div class="row mt-n1-9">
                    <div class="col-sm-6 col-lg-3 mt-1-9">
                        <div class="counter-style1">
                            <div class="ps-sm-4">
                                <h3 class="text-white mb-2 h1"><span class="countup">545</span></h3>
                                <p class="text-white font-weight-500 mb-0 fs-6">Cases Done</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-lg-3 mt-1-9">
                        <div class="counter-style1">
                            <div class="ps-sm-4">
                                <h3 class="text-white mb-2 h1"><span class="countup">700</span></h3>
                                <p class="text-white font-weight-500 mb-0 fs-6">Happy Clients</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-lg-3 mt-1-9">
                        <div class="counter-style1">
                            <div class="ps-sm-4">
                                <h3 class="text-white mb-2 h1"><span class="countup">230</span></h3>
                                <p class="text-white font-weight-500 mb-0 fs-6">Awards Win</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-lg-3 mt-1-9">
                        <div class="counter-style1">
                            <div class="ps-sm-4">
                                <h3 class="text-white mb-2 h1"><span class="countup">156</span></h3>
                                <p class="text-white font-weight-500 mb-0 fs-6">Worldwide site firm</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- PROCESS
        ================================================== -->
        <section>
            <div class="container">
                <div class="section-heading">
                    <span class="alt-font">Working Process</span>
                    <h2>Bold approaches expert counsel results that matter</h2>
                </div>
                <div class="row process-number-counter mt-n1-9">
                    <div class="col-sm-6 col-lg-3 mt-1-9">
                        <div class="process-style1">
                            <div class="process-img">
                                <img src="{{asset("v1")}}/img/content/process-01.jpg" class="rounded-circle" alt="...">
                            </div>
                            <div class="process-number"></div>
                            <h3 class="mb-3 h4">Listen Problems</h3>
                            <p class="w-md-85 mx-auto mb-4">The protection calling is one that accompanies great monetary prize.</p>
                            <div class="process-btn"><a href="{{asset("v1")}}/#!"><i class="fas fa-arrow-right"></i></a></div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-lg-3 mt-1-9">
                        <div class="process-style1">
                            <div class="process-img">
                                <img src="{{asset("v1")}}/img/content/process-02.jpg" class="rounded-circle" alt="...">
                            </div>
                            <div class="process-number"></div>
                            <h3 class="mb-3 h4">Some Research</h3>
                            <p class="w-md-85 mx-auto mb-4">The protection calling is one that accompanies great monetary prize.</p>
                            <div class="process-btn"><a href="{{asset("v1")}}/#!"><i class="fas fa-arrow-right"></i></a></div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-lg-3 mt-1-9">
                        <div class="process-style1">
                            <div class="process-img">
                                <img src="{{asset("v1")}}/img/content/process-03.jpg" class="rounded-circle" alt="...">
                            </div>
                            <div class="process-number"></div>
                            <h3 class="mb-3 h4">Make Shorting</h3>
                            <p class="w-md-85 mx-auto mb-4">The protection calling is one that accompanies great monetary prize.</p>
                            <div class="process-btn"><a href="{{asset("v1")}}/#!"><i class="fas fa-arrow-right"></i></a></div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-lg-3 mt-1-9">
                        <div class="process-style1 last-arrow">
                            <div class="process-img">
                                <img src="{{asset("v1")}}/img/content/process-04.jpg" class="rounded-circle" alt="...">
                            </div>
                            <div class="process-number"></div>
                            <h3 class="mb-3 h4">Do Final Work</h3>
                            <p class="w-md-85 mx-auto mb-4">The protection calling is one that accompanies great monetary prize.</p>
                            <div class="process-btn"><a href="{{asset("v1")}}/#!"><i class="fas fa-arrow-right"></i></a></div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- TEAM
        ================================================== -->
        <section class="bg-light">
            <div class="container">
                <div class="section-heading">
                    <span class="alt-font">Qualified Attorneys</span>
                    <h2 class="w-90 mx-auto">Successful expert & attorney works with our team</h2>
                </div>
                <div class="row mt-n1-9">
                    <div class="col-sm-6 col-lg-3 mt-1-9">
                        <div class="card card-style2 position-relative overflow-hidden rounded-0 border-0">
                            <img src="{{asset("v1")}}/img/team/team-01.jpg" alt="...">
                            <div class="card-body">
                                <div class="team-infos">
                                    <span class="mb-2 display-30">Civil Lawyer</span>
                                    <h4 class="h5 mb-3"><a href="{{asset("v1")}}/attorney-details.html" class="text-white">Jorge Meyer</a></h4>
                                    <ul class="social-icons">
                                        <li>
                                            <a href="{{asset("v1")}}/#!" class="text-white"><i class="fab fa-facebook-f"></i></a>
                                        </li>
                                        <li>
                                            <a href="{{asset("v1")}}/#!" class="text-white"><i class="fab fa-twitter"></i></a>
                                        </li>
                                        <li>
                                            <a href="{{asset("v1")}}/#!" class="text-white"><i class="fab fa-youtube"></i></a>
                                        </li>
                                        <li>
                                            <a href="{{asset("v1")}}/#!" class="text-white"><i class="fab fa-linkedin-in"></i></a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-lg-3 mt-1-9">
                        <div class="card card-style2 position-relative overflow-hidden rounded-0 border-0">
                            <img src="{{asset("v1")}}/img/team/team-02.jpg" alt="...">
                            <div class="card-body">
                                <div class="team-infos">
                                    <span class="mb-2 display-30">Financial Lawyer</span>
                                    <h4 class="h5 mb-3"><a href="{{asset("v1")}}/attorney-details.html" class="text-white">Ellen Gibb</a></h4>
                                    <ul class="social-icons">
                                        <li>
                                            <a href="{{asset("v1")}}/#!" class="text-white"><i class="fab fa-facebook-f"></i></a>
                                        </li>
                                        <li>
                                            <a href="{{asset("v1")}}/#!" class="text-white"><i class="fab fa-twitter"></i></a>
                                        </li>
                                        <li>
                                            <a href="{{asset("v1")}}/#!" class="text-white"><i class="fab fa-youtube"></i></a>
                                        </li>
                                        <li>
                                            <a href="{{asset("v1")}}/#!" class="text-white"><i class="fab fa-linkedin-in"></i></a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-lg-3 mt-1-9">
                        <div class="card card-style2 position-relative overflow-hidden rounded-0 border-0">
                            <img src="{{asset("v1")}}/img/team/team-03.jpg" alt="...">
                            <div class="card-body">
                                <div class="team-infos">
                                    <span class="mb-2 display-30">Criminal Lawyer</span>
                                    <h4 class="h5 mb-3"><a href="{{asset("v1")}}/attorney-details.html" class="text-white">Raymond Binder</a></h4>
                                    <ul class="social-icons">
                                        <li>
                                            <a href="{{asset("v1")}}/#!" class="text-white"><i class="fab fa-facebook-f"></i></a>
                                        </li>
                                        <li>
                                            <a href="{{asset("v1")}}/#!" class="text-white"><i class="fab fa-twitter"></i></a>
                                        </li>
                                        <li>
                                            <a href="{{asset("v1")}}/#!" class="text-white"><i class="fab fa-youtube"></i></a>
                                        </li>
                                        <li>
                                            <a href="{{asset("v1")}}/#!" class="text-white"><i class="fab fa-linkedin-in"></i></a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-lg-3 mt-1-9">
                        <div class="card card-style2 position-relative overflow-hidden rounded-0 border-0">
                            <img src="{{asset("v1")}}/img/team/team-04.jpg" alt="...">
                            <div class="card-body">
                                <div class="team-infos">
                                    <span class="mb-2 display-30">Family Lawyer</span>
                                    <h4 class="h5 mb-3"><a href="{{asset("v1")}}/attorney-details.html" class="text-white">Ollie Griffin</a></h4>
                                    <ul class="social-icons">
                                        <li>
                                            <a href="{{asset("v1")}}/#!" class="text-white"><i class="fab fa-facebook-f"></i></a>
                                        </li>
                                        <li>
                                            <a href="{{asset("v1")}}/#!" class="text-white"><i class="fab fa-twitter"></i></a>
                                        </li>
                                        <li>
                                            <a href="{{asset("v1")}}/#!" class="text-white"><i class="fab fa-youtube"></i></a>
                                        </li>
                                        <li>
                                            <a href="{{asset("v1")}}/#!" class="text-white"><i class="fab fa-linkedin-in"></i></a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- TESTIMONIAL
        ================================================== -->
        <section class="bg-img cover-background secondary-overlay" data-overlay-dark="9" data-background="{{asset("v1")}}/img/bg/bg-01.jpg">
            <div class="container">
                <div class="section-heading">
                    <span class="alt-font">Testimonials</span>
                    <h2 class="text-white">Our happy clients says about our work</h2>
                </div>
                <div class="testimonial-style1 owl-carousel owl-theme" data-slider-id="1">
                    <div>
                        <div class="testimonial-quote"><i class="fa fa-quote-left"></i></div>
                        <p class="text-white w-90 w-lg-70 w-xl-65 mx-auto mb-2-2 lead">I would also like to say thank you to all your staff. Lawyer was the best investment I ever made. We're loving it. I am so pleased with this product.</p>
                        <div class="display-31 text-warning mb-3">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                        </div>
                        <h4 class="h5 text-white mb-1">Victor Lucien</h4>
                        <span class="display-31 text-white">Assistant Counsel</span>
                    </div>
                    <div>
                        <div class="testimonial-quote"><i class="fa fa-quote-left"></i></div>
                        <p class="text-white w-90 w-lg-70 w-xl-65 mx-auto mb-2-2 lead">Lawyer is awesome! I can't say enough about lawyer. The best on the net! Lawyer impressed me on multiple levels. It's all good.</p>
                        <div class="display-31 text-warning mb-3">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                        </div>
                        <h4 class="h5 text-white mb-1">Christine Schneider</h4>
                        <span class="display-31 text-white">Prosecutor</span>
                    </div>
                    <div>
                        <div class="testimonial-quote"><i class="fa fa-quote-left"></i></div>
                        <p class="text-white w-90 w-lg-70 w-xl-65 mx-auto mb-2-2 lead">If you want real marketing that works and effective implementation - lawyer's got you covered. It's incredible. Lawyer is the most valuable business resource we have EVER purchased.</p>
                        <div class="display-31 text-warning mb-3">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                        </div>
                        <h4 class="h5 text-white mb-1">David Stigall</h4>
                        <span class="display-31 text-white">Trial Lawyer</span>
                    </div>
                </div>
                <div class="owl-thumbs text-center mt-1-9" data-slider-id="1">
                    <button class="owl-thumb-item bg-transparent">
                        <img src="{{asset("v1")}}/img/avatar/avatar-01.jpg" class="testimonial-img" alt="...">
                    </button>
                    <button class="owl-thumb-item bg-transparent">
                        <img src="{{asset("v1")}}/img/avatar/avatar-02.jpg" class="testimonial-img" alt="...">
                    </button>
                    <button class="owl-thumb-item bg-transparent">
                        <img src="{{asset("v1")}}/img/avatar/avatar-03.jpg" class="testimonial-img" alt="...">
                    </button>
                </div>
            </div>
        </section>

        <!-- PORTFOLIO
        ================================================== -->
        <section>
            <div class="container">
                <div class="section-heading">
                    <span class="alt-font">Case Studies</span>
                    <h2>Check case studie which is built with our experience</h2>
                </div>
                <div class="row portfolio-gallery mt-n1-9">
                    <div class="col-md-6 col-lg-4 mt-1-9" data-src="{{asset("v1")}}/img/case-study/case-study-01.jpg" data-sub-html="<h4 class='text-white'>Immigration Claims #01</h4>">
                        <div class="portfolio-style1">
                            <img src="{{asset("v1")}}/img/case-study/case-study-01.jpg" alt="...">
                            <div class="portfolio-overlay">
                                <div class="portfolio-info">
                                    <div class="portfolio-inner">
                                        <h4 class="h5 mb-4"><a href="{{asset("v1")}}/case-study-details.html" class="portfolio-link text-white">Immigration Claims</a></h4>
                                        <div class="porfolio-btn">
                                            <a href="{{asset("v1")}}/case-study-details.html"><span class="ti-zoom-in fs-5"></span></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-4 mt-1-9" data-src="{{asset("v1")}}/img/case-study/case-study-02.jpg" data-sub-html="<h4 class='text-white'>Child Protection #02</h4>">
                        <div class="portfolio-style1">
                            <img src="{{asset("v1")}}/img/case-study/case-study-02.jpg" alt="...">
                            <div class="portfolio-overlay">
                                <div class="portfolio-info">
                                    <div class="portfolio-inner">
                                        <h4 class="h5 mb-4"><a href="{{asset("v1")}}/case-study-details.html" class="portfolio-link text-white">Child Protection</a></h4>
                                        <div class="porfolio-btn">
                                            <a href="{{asset("v1")}}/case-study-details.html"><span class="ti-zoom-in fs-5"></span></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-4 mt-1-9" data-src="{{asset("v1")}}/img/case-study/case-study-03.jpg" data-sub-html="<h4 class='text-white'>Criminal Defence #03</h4>">
                        <div class="portfolio-style1">
                            <img src="{{asset("v1")}}/img/case-study/case-study-03.jpg" alt="...">
                            <div class="portfolio-overlay">
                                <div class="portfolio-info">
                                    <div class="portfolio-inner">
                                        <h4 class="h5 mb-4"><a href="{{asset("v1")}}/case-study-details.html" class="portfolio-link text-white">Criminal Defence</a></h4>
                                        <div class="porfolio-btn">
                                            <a href="{{asset("v1")}}/case-study-details.html"><span class="ti-zoom-in fs-5"></span></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-4 mt-1-9" data-src="{{asset("v1")}}/img/case-study/case-study-04.jpg" data-sub-html="<h4 class='text-white'>Civil Rights #04</h4>">
                        <div class="portfolio-style1">
                            <img src="{{asset("v1")}}/img/case-study/case-study-04.jpg" alt="...">
                            <div class="portfolio-overlay">
                                <div class="portfolio-info">
                                    <div class="portfolio-inner">
                                        <h4 class="h5 mb-4"><a href="{{asset("v1")}}/case-study-details.html" class="portfolio-link text-white">Civil Rights</a></h4>
                                        <div class="porfolio-btn">
                                            <a href="{{asset("v1")}}/case-study-details.html"><span class="ti-zoom-in fs-5"></span></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-4 mt-1-9" data-src="{{asset("v1")}}/img/case-study/case-study-05.jpg" data-sub-html="<h4 class='text-white'>Bank & Financial #05</h4>">
                        <div class="portfolio-style1">
                            <img src="{{asset("v1")}}/img/case-study/case-study-05.jpg" alt="...">
                            <div class="portfolio-overlay">
                                <div class="portfolio-info">
                                    <div class="portfolio-inner">
                                        <h4 class="h5 mb-4"><a href="{{asset("v1")}}/case-study-details.html" class="portfolio-link text-white">Bank & Financial</a></h4>
                                        <div class="porfolio-btn">
                                            <a href="{{asset("v1")}}/case-study-details.html"><span class="ti-zoom-in fs-5"></span></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-4 mt-1-9" data-src="{{asset("v1")}}/img/case-study/case-study-06.jpg" data-sub-html="<h4 class='text-white'>Family Violence #06</h4>">
                        <div class="portfolio-style1">
                            <img src="{{asset("v1")}}/img/case-study/case-study-06.jpg" alt="...">
                            <div class="portfolio-overlay">
                                <div class="portfolio-info">
                                    <div class="portfolio-inner">
                                        <h4 class="h5 mb-4"><a href="{{asset("v1")}}/case-study-details.html" class="portfolio-link text-white">Family Violence</a></h4>
                                        <div class="porfolio-btn">
                                            <a href="{{asset("v1")}}/case-study-details.html"><span class="ti-zoom-in fs-5"></span></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- EXTRA
        ================================================== -->
        <section class="bg-img cover-background secondary-overlay" data-overlay-dark="8" data-background="{{asset("v1")}}/img/bg/bg-05.jpg">
            <div class="container">
                <div class="row align-items-center mt-n7">
                    <div class="col-lg-8 mt-7 text-center text-lg-start">
                        <div class="border-bottom border-color-light-white pb-1-9 pb-md-2-5 mb-1-6 mb-md-2-5">
                            <h2 class="h1 text-white mb-1-6">Our goals and achievements on lawyers practice</h2>
                            <p class="mb-0 w-95 text-white display-29 display-sm-28 opacity9 mx-auto mx-lg-0">It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters.</p>
                        </div>
                        <div class="client-carousel owl-carousel owl-theme">
                            <div class="text-center">
                                <img src="{{asset("v1")}}/img/partners/partner-01.png" alt="...">
                            </div>
                            <div class="text-center">
                                <img src="{{asset("v1")}}/img/partners/partner-02.png" alt="...">
                            </div>
                            <div class="text-center">
                                <img src="{{asset("v1")}}/img/partners/partner-03.png" alt="...">
                            </div>
                            <div class="text-center">
                                <img src="{{asset("v1")}}/img/partners/partner-04.png" alt="...">
                            </div>
                            <div class="text-center">
                                <img src="{{asset("v1")}}/img/partners/partner-05.png" alt="...">
                            </div>
                            <div class="text-center">
                                <img src="{{asset("v1")}}/img/partners/partner-06.png" alt="...">
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 text-center mt-7">
                        <div class="story-video">
                            <a class="video video_btn small bg-white" href="{{asset("v1")}}/https://www.youtube.com/watch?v=oj1gAYwm6AA"><i class="fas fa-play text-primary"></i></a>
                            <div class="d-inline-block align-middle ps-1-6 ps-lg-2-2 text-white text-start font-weight-600">Watch<span class="text-uppercase d-block">intro video</span></div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- BLOG
        ================================================== -->
        <section>
            <div class="container">
                <div class="section-heading">
                    <span class="alt-font">Recent Article</span>
                    <h2>Our Lawyer has been good friend of mine for long time</h2>
                </div>
                <div class="row mt-n1-9">
                    <div class="col-md-6 col-lg-4 mt-1-9">
                        <article class="card card-style3 position-relative border-0 rounded-0 bg-transparent h-100">
                            <div class="card-img"><img src="{{asset("v1")}}/img/blog/blog-01.jpg" alt="...">
                                <div class="tags">
                                    <a href="{{asset("v1")}}/#!">Lawyer</a>
                                    <a href="{{asset("v1")}}/#!">Fraud case</a>
                                </div>
                            </div>
                            <div class="card-body">
                                <ul class="list-unstyled mb-3">
                                    <li class="d-inline-block me-3"><a href="{{asset("v1")}}/#!"><i class="far fa-calendar-check me-1 text-primary"></i> Apr. 25, 2023</a></li>
                                    <li class="d-inline-block"><a href="{{asset("v1")}}/#!"><i class="far fa-comment-dots me-1 text-primary"></i> 10 Comment</a></li>
                                </ul>
                                <h3 class="mb-3 h4"><a href="{{asset("v1")}}/blog-details.html">Seven secrets you will not want to know about lawyer.</a></h3>
                                <p>It is critical to recruit a safeguard legal advisor. The general set of laws is planned and...</p>
                                <a href="{{asset("v1")}}/blog-details.html" class="font-weight-500">Read more<i class="fas fa-long-arrow-alt-right align-middle ms-2 display-30"></i></a>
                            </div>
                        </article>
                    </div>
                    <div class="col-md-6 col-lg-4 mt-1-9">
                        <article class="card card-style3 position-relative border-0 rounded-0 bg-transparent h-100">
                            <div class="card-img"><img src="{{asset("v1")}}/img/blog/blog-02.jpg" alt="...">
                                <div class="tags">
                                    <a href="{{asset("v1")}}/#!">Lawyer</a>
                                    <a href="{{asset("v1")}}/#!">Learning</a>
                                </div>
                            </div>
                            <div class="card-body">
                                <ul class="list-unstyled mb-3">
                                    <li class="d-inline-block me-3"><a href="{{asset("v1")}}/#!"><i class="far fa-calendar-check me-1 text-primary"></i> Apr. 21, 2023</a></li>
                                    <li class="d-inline-block"><a href="{{asset("v1")}}/#!"><i class="far fa-comment-dots me-1 text-primary"></i> 20 Comment</a></li>
                                </ul>
                                <h3 class="mb-3 h4"><a href="{{asset("v1")}}/blog-details.html">5 advices that you listen before studying lawyer.</a></h3>
                                <p>It is critical to recruit a safeguard legal advisor. The general set of laws is planned and...</p>
                                <a href="{{asset("v1")}}/blog-details.html" class="font-weight-500">Read more<i class="fas fa-long-arrow-alt-right align-middle ms-2 display-30"></i></a>
                            </div>
                        </article>
                    </div>
                    <div class="col-md-6 col-lg-4 mt-1-9">
                        <article class="card card-style3 position-relative border-0 rounded-0 bg-transparent h-100">
                            <div class="card-img"><img src="{{asset("v1")}}/img/blog/blog-03.jpg" alt="...">
                                <div class="tags">
                                    <a href="{{asset("v1")}}/#!">Lawyer</a>
                                    <a href="{{asset("v1")}}/#!">Legal Advise</a>
                                </div>
                            </div>
                            <div class="card-body">
                                <ul class="list-unstyled mb-3">
                                    <li class="d-inline-block me-3"><a href="{{asset("v1")}}/#!"><i class="far fa-calendar-check me-1 text-primary"></i> Apr. 18, 2023</a></li>
                                    <li class="d-inline-block"><a href="{{asset("v1")}}/#!"><i class="far fa-comment-dots me-1 text-primary"></i> 08 Comment</a></li>
                                </ul>
                                <h3 class="mb-3 h4"><a href="{{asset("v1")}}/blog-details.html">The millionaire guide on lawyer to help you get rich.</a></h3>
                                <p>It is critical to recruit a safeguard legal advisor. The general set of laws is planned and...</p>
                                <a href="{{asset("v1")}}/blog-details.html" class="font-weight-500">Read more<i class="fas fa-long-arrow-alt-right align-middle ms-2 display-30"></i></a>
                            </div>
                        </article>
                    </div>
                </div>
            </div>
        </section>

        <!-- FOOTER
        ================================================== -->
        <footer class="bg-secondary pt-0">
            <div class="container border-bottom border-color-light-white py-2-5 py-md-6 mb-6 mb-md-8 mb-lg-10">
                <div class="row justify-content-center mt-n1-9">
                    <div class="col-sm-6 col-lg-4 mt-1-9">
                        <div class="d-flex align-items-center">
                            <div class="flex-shrink-0">
                                <img src="{{asset("v1")}}/img/icons/icon-07.png" alt="...">
                            </div>
                            <div class="flex-grow-1 borders-start border-color-light-white ps-4 ms-3">
                                <h5 class="text-white">Request quote</h5>
                                <p class="text-white mb-0 display-31 opacity9">Send us your request</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-lg-4 mt-1-9">
                        <div class="d-flex align-items-center">
                            <div class="flex-shrink-0">
                                <img src="{{asset("v1")}}/img/icons/icon-08.png" alt="...">
                            </div>
                            <div class="flex-grow-1 borders-start border-color-light-white ps-4 ms-3">
                                <h5 class="text-white">Investigation</h5>
                                <p class="text-white mb-0 display-31 opacity9">We will investigate about your case</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-4 mt-1-9">
                        <div class="d-flex align-items-center">
                            <div class="flex-shrink-0">
                                <img src="{{asset("v1")}}/img/icons/icon-09.png" alt="...">
                            </div>
                            <div class="flex-grow-1 borders-start border-color-light-white ps-4 ms-3">
                                <h5 class="text-white">Case fight</h5>
                                <p class="text-white mb-0 display-31 opacity9">We will fight your case in court</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="row mt-n2-6">
                    <div class="col-sm-6 col-xl-3 mt-2-6">
                        <div class="mb-1-6 mb-lg-1-9">
                            <a href="{{asset("v1")}}/index-2.html" class="footer-logo"><img src="{{asset("v1")}}/img/logos/footer-light-logo.png" alt="..."></a>
                        </div>
                        <p class="text-white mb-1-6 mb-lg-1-9 opacity9 display-30 display-lg-29">Lawyer is a group of highly experienced value-based and case lawyers from a portion of the country's greatest and most first class law offices.</p>
                        <ul class="footer-social-style1">
                            <li><a href="{{asset("v1")}}/#!"><i class="fab fa-facebook-f"></i></a></li>
                            <li><a href="{{asset("v1")}}/#!"><i class="fab fa-twitter"></i></a></li>
                            <li><a href="{{asset("v1")}}/#!"><i class="fab fa-youtube"></i></a></li>
                            <li><a href="{{asset("v1")}}/#!"><i class="fab fa-linkedin-in"></i></a></li>
                        </ul>
                    </div>
                    <div class="col-sm-6 col-xl-3 mt-2-6">
                        <div class="ps-sm-1-6 ps-md-1-9">
                            <h3 class="footer-title">Contact us</h3>
                            <ul class="contact-list">
                                <li><span class="fas fa-map-marker-alt pe-3 text-white"></span>66 Guild Street 512B, Great NT.</li>
                                <li><span class="fa fa-phone-alt pe-3 text-white"></span><a href="{{asset("v1")}}/#!">(+44) 123 456 7892</a></li>
                                <li><span class="fas fa-globe pe-3 text-white"></span><a href="{{asset("v1")}}/#!">www.yoursite.com</a></li>
                                <li><span class="fa fa-envelope pe-3 text-white"></span><a href="{{asset("v1")}}/#!">addyour@emailhere</a></li>
                            </ul>
                        </div>
                    </div>

                    <div class="col-sm-6 col-xl-3 mt-2-6">
                        <div class="ps-xl-1-9">
                            <h3 class="footer-title">Our services</h3>
                            <ul class="footer-list-style1">
                                <li><a href="{{asset("v1")}}/business-law.html">Business Law</a></li>
                                <li><a href="{{asset("v1")}}/criminal-law.html">Criminal Law</a></li>
                                <li><a href="{{asset("v1")}}/divorce-law.html">Divorce Law</a></li>
                                <li><a href="{{asset("v1")}}/education-law.html">Education Law</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-sm-6 col-xl-3 mt-2-6">
                        <div class="ps-sm-1-6 ps-md-1-9">
                            <h3 class="footer-title">Trending post</h3>
                            <div class="d-flex align-items-center mb-1-6">
                                <div class="flex-shrink-0">
                                    <img src="{{asset("v1")}}/img/instagram/insta-01.jpg" alt="...">
                                </div>
                                <div class="flex-grow-1 ms-4">
                                    <h4 class="display-30 text-white"><a href="{{asset("v1")}}/blog-details.html" class="text-white">Mediation Useful Family Law Cases?</a></h4>
                                    <span class="display-31 text-white"><i class="far fa-calendar-check me-2 text-white"></i>Apr 27, 2023</span>
                                </div>
                            </div>
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0">
                                    <img src="{{asset("v1")}}/img/instagram/insta-02.jpg" alt="...">
                                </div>
                                <div class="flex-grow-1 ms-4">
                                    <h4 class="display-30 text-white"><a href="{{asset("v1")}}/blog-details.html" class="text-white">Allow to mile wound be place leave.</a></h4>
                                    <span class="display-31 text-white"><i class="far fa-calendar-check me-2 text-white"></i>Apr 24, 2023</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="footer-bar">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12 text-center">
                            <p class="d-inline-block text-white mb-0 display-30 display-lg-29">&copy; <span class="current-year"></span> Lawyer Powered by&nbsp;<a href="{{asset("v1")}}/#!" class="text-primary white-hover">Chitrakoot Web</a>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </footer>

    </div>

    <!-- BUY TEMPLATE
    ================================================== -->
    <div class="buy-theme alt-font d-none d-lg-inline-block"><a href="{{asset("v1")}}/https://wrapbootstrap.com/theme/lawyer-attorney-and-lawyers-html-template-WB0165D4R" target="_blank"><i class="fas fa-cart-plus"></i><span>Buy Template</span></a></div>

    <div class="all-demo alt-font d-none d-lg-inline-block"><a href="{{asset("v1")}}/https://www.chitrakootweb.com/contact.html" target="_blank"><i class="far fa-envelope"></i><span>Quick Question?</span></a></div>

    <!-- start scroll to top -->
    <a href="{{asset("v1")}}/#!" class="scroll-to-top"><i class="fas fa-angle-up" aria-hidden="true"></i></a>
    <!-- end scroll to top -->

    <!-- jQuery -->
    <script src="{{asset("v1")}}/js/jquery.min.js"></script>

    <!-- popper js -->
    <script src="{{asset("v1")}}/js/popper.min.js"></script>

    <!-- bootstrap -->
    <script src="{{asset("v1")}}/js/bootstrap.min.js"></script>

    <!-- core.min.js -->
    <script src="{{asset("v1")}}/js/core.min.js"></script>

    <!-- search -->
    <script src="{{asset("v1")}}/search/search.js"></script>

    <!-- custom scripts -->
    <script src="{{asset("v1")}}/js/main.js"></script>

    <!-- form plugins js -->
    <script src="{{asset("v1")}}/quform/js/plugins.js"></script>

    <!-- form scripts js -->
    <script src="{{asset("v1")}}/quform/js/scripts.js"></script>

    <!-- all js include end -->

</body>


<!-- Mirrored from lawyer.websitelayout.net/ by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 25 Feb 2025 19:50:50 GMT -->
</html>
