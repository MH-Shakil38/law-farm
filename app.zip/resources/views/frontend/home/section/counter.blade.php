<section class="bg-img cover-background secondary-overlay" data-overlay-dark="8" data-background="{{asset("v1")}}/img/bg/bg-07.jpg">
    <div class="container">
        <div class="row mt-n1-9">
            <div class="col-sm-6 col-lg-3 mt-1-9">
                <div class="counter-style1">
                    <div class="ps-sm-4">
                        <h3 class="text-white mb-2 h1"><span class="countup">545</span></h3>
                        <p class="text-white font-weight-500 mb-0 fs-6">Cases Done</p>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-lg-3 mt-1-9">
                <div class="counter-style1">
                    <div class="ps-sm-4">
                        <h3 class="text-white mb-2 h1"><span class="countup">700</span></h3>
                        <p class="text-white font-weight-500 mb-0 fs-6">Happy Clients</p>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-lg-3 mt-1-9">
                <div class="counter-style1">
                    <div class="ps-sm-4">
                        <h3 class="text-white mb-2 h1"><span class="countup">230</span></h3>
                        <p class="text-white font-weight-500 mb-0 fs-6">Awards Win</p>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-lg-3 mt-1-9">
                <div class="counter-style1">
                    <div class="ps-sm-4">
                        <h3 class="text-white mb-2 h1"><span class="countup">156</span></h3>
                        <p class="text-white font-weight-500 mb-0 fs-6">Worldwide site firm</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
