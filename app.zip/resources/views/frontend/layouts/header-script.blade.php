
    <!-- favicon -->
    <link rel="shortcut icon" href="{{asset('website/logo.jpg')}}" />
    <link rel="apple-touch-icon" href="https://attorneypema.com/website/logo.jpg" />
    <link rel="apple-touch-icon" sizes="72x72" href="https://attorneypema.com/website/logo.jpg" />
    <link rel="apple-touch-icon" sizes="114x114" href="https://attorneypema.com/website/logo.jpg" />

    <!-- plugins -->
    <link rel="stylesheet" href="{{asset("v1")}}/css/plugins.css" />

    <!-- search css -->
    <link rel="stylesheet" href="{{asset("v1")}}/search/search.css" />

    <!-- quform css -->
    <link rel="stylesheet" href="{{asset("v1")}}/quform/css/base.css">

    <!-- theme core css -->
    <link href="{{asset("v1")}}/css/styles.css" rel="stylesheet">
