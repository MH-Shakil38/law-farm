
    <!-- start scroll to top -->
    <a href="{{asset("v1")}}/#!" class="scroll-to-top"><i class="fas fa-angle-up" aria-hidden="true"></i></a>
    <!-- end scroll to top -->

    <!-- jQuery -->
    <script src="{{asset("v1")}}/js/jquery.min.js"></script>

    <!-- popper js -->
    <script src="{{asset("v1")}}/js/popper.min.js"></script>

    <!-- bootstrap -->
    <script src="{{asset("v1")}}/js/bootstrap.min.js"></script>

    <!-- core.min.js -->
    <script src="{{asset("v1")}}/js/core.min.js"></script>

    <!-- search -->
    <script src="{{asset("v1")}}/search/search.js"></script>

    <!-- custom scripts -->
    <script src="{{asset("v1")}}/js/main.js"></script>

    <!-- form plugins js -->
    <script src="{{asset("v1")}}/quform/js/plugins.js"></script>

    <!-- form scripts js -->
    <script src="{{asset("v1")}}/quform/js/scripts.js"></script>

    <!-- all js include end -->
