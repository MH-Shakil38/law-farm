<input class="form-control datetimepicker border-none hearing_date" id="timepicker2" type="text"
    style="width: 200px;background: #065bb3;color:#fff" placeholder="{{ $today == true ? 'TOday Client' : 'Select Hearing Date' }}"
    data-options='{"mode":"range","dateFormat":"d/m/y","disableMobile":true}' />
