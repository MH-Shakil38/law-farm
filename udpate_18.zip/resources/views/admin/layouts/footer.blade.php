<footer class="footer">
    <div class="row g-0 justify-content-between fs-10 mt-4 mb-3">
        <div class="col-12 col-sm-auto text-center">
            <p class="mb-0 text-600">Law Office of Pema Lhamu Bhutia PC<span
                    class="d-none d-sm-inline-block">| </span><br class="d-sm-none" /> 2024 &copy;
                <a href="{{ url('/') }}">Pema Lhamu Bhutia</a></p>
        </div>
        <div class="col-12 col-sm-auto text-center">
            <p class="mb-0 text-600">v1.0.0</p>
        </div>
    </div>
</footer>
