@extends('admin.layouts.app')
@section('content')
    @include('admin.dashboard.super-admin')
    <div class="spinner-border" role="status"><span class="visually-hidden">Loading...</span></div>
@endsection
